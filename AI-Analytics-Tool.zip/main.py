import pandas as pd

# Load sample data
data = pd.read_csv('data/sample_data.csv')

# Simple analytics
print("=== AI Analytics Demo ===")
print("Data Summary:")
print(data.describe())

# Example: calculate average of numeric columns
averages = data.mean(numeric_only=True)
print("\nColumn Averages:")
print(averages)
